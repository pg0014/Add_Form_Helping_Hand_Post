import React,{useState} from "react"
import "./style.css";
import {Modal, ModalBody, ModalHeader, Row,Col} from "reactstrap";

function AddPeople(){
    const [modal,setmodal]=useState(false)
    const [textareaheight, setTextareaheight] = useState(1); 
  
    function handleChange(event) { 
      
      console.log( event.target.rows ) 
      const height = event.target.scrollHeight; 
      const rowHeight = 15; 
      const trows = Math.ceil(height / rowHeight) - 1; 
      
      if (trows (textareaheight)) { 
        
        setTextareaheight(trows); 
        
      } 
      
    } 
    
    return(
       <div>
        <Modal 
        size="lg" 
        isOpen={modal} 
        toggle={()=>setmodal(!modal)}>
            <ModalHeader
            toggle={()=>setmodal(!modal)}>
                Add people to need help
            </ModalHeader>
            <ModalBody>
                <form>
                    <Row>
                        <Col lg={12}>
                            <div class="category">
                                <h5><label htmlFor="name">Category</label></h5>
                                <fieldset>
                                    <div className="container">
                                    <label>
                                     <input 
                                     type="radio" 
                                     class="radio-custom"
                                     value="Food"  
                                     id="food"
                                     name="radio1"/>
                                     <span class="radio-custom-label">Food</span>
                                     </label>
                                     <label>
                                        <input 
                                        type="radio" 
                                        class="radio-custom"
                                        value="Medical help" 
                                        id="medical"
                                        name="radio1" /> 
                                    <span class="radio-custom-label">Medical help</span>
                                    </label>
                                    <label>
                                     <input 
                                     type="radio" 
                                     class="radio-custom"
                                     value="Food"  
                                     id="wearing cloths"
                                     name="radio1"/>
                                     <span class="radio-custom-label">Wearing cloths</span>
                                     </label>
                                </div>
                                </fieldset>
                            </div>
                            <div class="noofpeople">
                            <h5><label htmlFor="name">No of people</label></h5>
                            <fieldset>
                                    <div className="container">
                                    <label>
                                     <input 
                                     type="radio" 
                                     class="radio-custom"
                                     value="1"  
                                     id="food"
                                     name="radio2"/>
                                     <span class="radio-custom-label">1</span>
                                     </label>
                                     <label>
                                        <input 
                                        type="radio" 
                                        class="radio-custom"
                                        value="2-5" 
                                        id="medical"
                                        name="radio2" /> 
                                    <span class="radio-custom-label">2-5</span>
                                    </label>
                                    <label>
                                     <input 
                                     type="radio" 
                                     class="radio-custom"
                                     value="6-10"  
                                     id="wearing cloths"
                                     name="radio2"/>
                                     <span class="radio-custom-label">6-10</span>
                                     </label>
                                </div>
                                </fieldset>
                                </div>
                                <div class="priority">
                                <h5><label htmlFor="name">Priority</label></h5>
                                <fieldset>
                                    <div className="container">
                                    <label>
                                     <input 
                                     type="radio" 
                                     class="radio-custom"
                                     value="immediate"  
                                     name="radio3"/>
                                     <span class="radio-custom-label">Immediate</span>
                                     </label>
                                     <label>
                                        <input 
                                        type="radio" 
                                        value="urgent" 
                                        name="radio3" /> 
                                    <span class="radio-custom-label">Urgent</span>
                                    </label>
                                    <label>
                                     <input 
                                     type="radio" 
                                     class="radio-custom"
                                     value="normal"  
                                     name="radio3"/>
                                     <span class="radio-custom-label">Normal</span>
                                     </label>
                                </div>
                                </fieldset>
                                </div>
                                <div class="post">
                                <h5><label htmlFor="name">Post expiry</label></h5>
                                <fieldset>
                                    <div className="container">
                                    <label>
                                     <input 
                                     type="radio" 
                                     class="radio-custom"
                                     value="1d"  
                                     name="radio4"/>
                                     <span class="radio-custom-label">1d</span>
                                     </label>
                                     <label>
                                        <input 
                                        type="radio" 
                                        class="radio-custom"
                                        value="6hrs" 
                                        name="radio4" /> 
                                    <span class="radio-custom-label">6hrs</span>
                                    </label>
                                    <label>
                                     <input 
                                     type="radio" 
                                     class="radio-custom"
                                     value="1w"  
                                     name="radio4"/>
                                     <span class="radio-custom-label">1w</span>
                                     </label>
                                     <label>
                                     <input 
                                     type="radio" 
                                     class="radio-custom"
                                     value="3hrs"  
                                     name="radio5"/>
                                     <span class="radio-custom-label">3hrs</span>
                                     </label>
                                </div>
                                </fieldset>
                                </div>
                                
                            <div class="add">
                            <h5><label htmlFor="name">Address</label></h5>
                                <textarea rows={textareaheight}  style={{width:750,height:40}}  onChange={handleChange}></textarea>
                            </div>
                            <span>Make sure entered address is complete,correct and it is your Shop/Office/</span>
                            <div class="landmark">
                                <textarea  rows={2}  style={{width:750,height:60}} placeholder="Landmark"></textarea>
                            </div>
                        </Col>
                    </Row>
                </form>
            </ModalBody>
        </Modal>
        <button className="btn mt-3" style={{backgroundColor:"#7f0c86",color:"white"}} onClick={()=>setmodal(true)}>Open</button>
       </div>
    )
}

export default AddPeople;